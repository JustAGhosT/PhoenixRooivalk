# @phoenix/sdk

TypeScript SDK for PhoenixRooivalk

## Generate types from proto

```bash
cd packages/sdk
pnpm install
pnpm run generate:proto
pnpm run build
```

The `protos/` directory contains the source `.proto` files. Generated files will be emitted into `src/gen/`.
