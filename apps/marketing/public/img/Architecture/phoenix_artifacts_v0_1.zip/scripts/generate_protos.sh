#!/usr/bin/env bash
set -euo pipefail
# Generate Rust + TS from protobufs

# Rust (prost-build happens at cargo build time)
echo "[Rust] Build proto crate:"
( cd crates/proto && cargo build )

# TypeScript (ts-proto)
echo "[TS] Install deps and generate:"
( cd packages/sdk && pnpm install && pnpm run generate:proto && pnpm run build )

echo "Done."
