# phoenix-proto (Rust)

Protobuf schema crate for PhoenixRooivalk.

## Build

```bash
cd crates/proto
cargo build
```

This triggers `prost-build` to compile all `.proto` files in `protos/` into Rust types.
