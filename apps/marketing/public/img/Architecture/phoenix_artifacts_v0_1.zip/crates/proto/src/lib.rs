//! Generated protobuf types for PhoenixRooivalk.
//! Build with `cargo build` to trigger prost-build codegen.
//! Import modules via `include!` from OUT_DIR.
include!(concat!(env!("OUT_DIR"), "/phoenix.rs"));
