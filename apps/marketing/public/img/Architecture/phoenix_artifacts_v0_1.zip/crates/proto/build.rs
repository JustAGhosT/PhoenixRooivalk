fn main() {
    let protos = &[
        "protos/command.proto",
        "protos/telemetry.proto",
        "protos/alert.proto",
        "protos/evidence.proto",
        "protos/mesh_policy.proto",
    ];
    let includes = &["protos"];
    prost_build::Config::new()
        .out_dir(std::env::var("OUT_DIR").unwrap())
        .compile_protos(protos, includes)
        .expect("prost-build failed");
}
